<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Vitaliy Kondratyuk <vitaliy.kondratyuk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'IpAddressJoins_TestCase::main' );
}

require_once dirname( __FILE__ ) . '/OnApp_TestCase.php';
require_once dirname( __FILE__ ) . '/ONAPP/VirtualMachine/IpAddressJoin.php';

/**
 * Unit Tests for serializing arrays
 *
 */
class IpAddressJoins_TestCase extends OnApp_TestCase {

    private $_onapp_config = array( );
    private $_fixture;

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'IpAddressJoins_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
        parent::setUp( );
        $this->_onapp_config = $this->getConfig( );

        $obj = new ONAPP_VirtualMachine( );
        $obj->auth(
            $this->_onapp_config[ 'hostname' ],
            $this->_onapp_config[ 'username' ],
            $this->_onapp_config[ 'password' ]
        );

        $list = $obj->getList( );
        $this->fixture = $list[ 0 ]->_id;
    }

    protected function tearDown( ) {
    }

    public function testCheckAttributesList( ) {
        $obj = new ONAPP_VirtualMachine_IpAddressJoin( );
        $obj->_virtual_machine_id = $this->fixture;

        $this->CheckAttributes( $obj );
    }

    public function testCheckObjectFields( ) {
        $obj = new ONAPP_VirtualMachine_IpAddressJoin( );

        $this->CheckObjectFields( $obj );
    }
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'IpAddressJoins_TestCase::main' ) {
    IpAddressJoins_TestCase::main( );
}