#!/bin/sh

## VARIABLES:
DATE=`date +"%s"`

## DIRS:

if [ -r "`dirname $0 | sed 's/\/.*$//'`" ]; then
    SCRIPT_DIR=`pwd`/`dirname $0`
else
    SCRIPT_DIR=`dirname $0`
fi
TESTS_DIR="$SCRIPT_DIR/../tests"
BASE_DIR="/tmp/onapp/PHP/wrapper/tests"

#########################################################################################
##
##  Functions
##
#########################################################################################

show_help() {
    echo "TODO: help message"
}

#
# message() and error() functions are used throughout a script for debug output
#
# Usage:
# message "<message text>"
# error "<error message text>"
#

message() {
    local message="$1"

    echo "`date +%b\ %e\ %R\:%S` INFO ${message}"
}

error() {
    local error="$1"

    echo "`date +%b\ %e\ %R\:%S` ERROR ${error}"

    exit 1
}

init_base_dir() {
    message "Initialize test directory"

    if [ ! -z "$FORCE" ]; then
        rm -rf $BASE_DIR
    fi

    if [ -d $BASE_DIR ]; then
        error "mkdir: cannot create directory $BASE_DIR': Directory exists"
    else
        message "Create directory $BASE_DIR"

        mkdir -p $BASE_DIR
    fi
}

copy_tests() {
    message "Copy all test cases"

    if [ -d $BASE_DIR ]; then
        cp -r $TESTS_DIR/* $BASE_DIR
    else
        error "cp: cannot create directory $BASE_DIR': Directory not found"
    fi
}

unpack_test_framework() {
    message "Unpack PHPUnit lib in to test directory"

    local php_unit=`ls -la $SCRIPT_DIR/../src | grep PHPUnit | sed 's/^.* //'`

    local php_unit_name=`echo $php_unit | sed 's/\.[^.]*$//'`

    cd $BASE_DIR

    tar -xf $SCRIPT_DIR/../src/$php_unit $php_unit_name/PHPUnit/

    cd -

    mv $BASE_DIR/$php_unit_name/PHPUnit/ $BASE_DIR

    rm -rf $BASE_DIR/$php_unit_name
}

copy_ONAPP_wrapper() {
    message "Copy PHP ONAPP API Wrapper into $BASE_DIR/libs"

    if [ -d "$SCRIPT_DIR/../ONAPP" ]; then
        cp -r $SCRIPT_DIR/../ONAPP $BASE_DIR
    else
        error "Directory $SCRIPT_DIR/../ONAPP not found"
    fi

    if [ -d "$SCRIPT_DIR/../libs" ]; then
        cp -r $SCRIPT_DIR/../libs $BASE_DIR
    else
        error "Directory $SCRIPT_DIR/../libs not found"
    fi
}

run_tests() {
    message "Run tests"

    if [ -f "$BASE_DIR/AllTests.php" ]; then
        php $BASE_DIR/AllTests.php ${DEBUG}

    else
        error "File $BASE_DIR/AllTests.php not found"
    fi
}

#########################################################################################
##
##  Main
##
#########################################################################################

#
# Arguments retrieval
#
while [ $# -gt 0 ]
do
    case "$1" in
        -h|--help)
         show_help
         exit 0
        ;;

        -o|--output)
         shift
         OUTPUT_DIR="$1"
         shift
        ;;

        --force)
         shift
         FORCE=true
        ;;

        -d|--debug)
         shift
         DEBUG="debug"
         shift
        ;;

        -*)
         echo "Unknown option: $1"
         exit 1
        ;;

        *)
         show_help
         exit;
        ;;
    esac
done

message  "PHPUnit test for ONAPP API Wrapper started."

init_base_dir

copy_tests

unpack_test_framework

copy_ONAPP_wrapper

run_tests
