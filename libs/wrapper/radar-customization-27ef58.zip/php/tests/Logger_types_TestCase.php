<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'Logger_types_TestCase::main' );
}

require_once 'PHPUnit/Framework/TestCase.php';
require_once 'PHPUnit/Framework/TestSuite.php';
require_once 'PHPUnit/TextUI/TestRunner.php';

require_once dirname( __FILE__ ) . '/ONAPP/Logger.php';

/**
 * Unit Tests for serializing arrays
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */
class Logger_types_TestCase extends PHPUnit_Framework_TestCase {

    private $_output = "\[.*\] \[MSG\]   setTimezone: Change default date.timezone.
\[.*\] \[WARN\]  setTimezone: Script timezone differs from ini-set timezone.\n";

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'Logger_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
    }

    protected function tearDown( ) {
    }

    /**
     * Test log types output
     */
    public function testAddOutput( ) {
        $s = new Logger( );

        $s->setTimezone( );

        $s->add( "Test" );

        $this->assertRegExp(
            "/" .
            $this->_output .
            "\[.*\] \[MSG\]   Test$" .
            "/"
            , $s->logs( )
            , "Wrong default loger output:\n" . $s->logs( )
        );
    }

    /**
     * Test warning types output
     */
    public function testWarnOutput( ) {
        $s = new Logger( );

        $s->setTimezone( );

        $s->warning( "Test" );

        $this->assertRegExp(
            "/" .
            $this->_output .
            "\[.*\] \[WARN\]  Test$" .
            "/"
            , $s->logs( )
            , "Wrong warining loger output\n" . $s->logs( )
        );
    }
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'Logger_types_TestCase::main' ) {
    Logger_types_TestCase::main( );
}