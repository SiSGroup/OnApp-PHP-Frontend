<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Vitaliy Kondratyuk <vitaliy.kondratyuk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'NetworkInterfaces_TestCase::main' );
}

require_once dirname( __FILE__ ) . '/OnApp_TestCase.php';
require_once dirname( __FILE__ ) . '/ONAPP/VirtualMachine/NetworkInterface.php';

/**
 * Unit Tests for serializing arrays
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */
class NetworkInterfaces_TestCase extends OnApp_TestCase {

    private $_onapp_config = array( );
    private $_fixture;

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'NetworkInterfaces_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
        parent::setUp( );
        $this->_onapp_config = $this->getConfig( );

        $obj = new ONAPP_VirtualMachine( );
        $obj->auth(
            $this->_onapp_config[ 'hostname' ],
            $this->_onapp_config[ 'username' ],
            $this->_onapp_config[ 'password' ]
        );

        $list = $obj->getList( );
        $this->fixture = $list[ 0 ]->_id;
    }

    protected function tearDown( ) {
    }

    public function testCheckAttributesList( ) {
        $obj = new ONAPP_VirtualMachine_NetworkInterface( );
        $obj->_virtual_machine_id = $this->fixture;

        $this->CheckAttributes( $obj );
    }

    public function testCheckObjectFields( ) {
        $obj = new ONAPP_VirtualMachine_NetworkInterface( );

        $this->CheckObjectFields( $obj );
    }
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'NetworkInterfaces_TestCase::main' ) {
    NetworkInterfaces_TestCase::main( );
}