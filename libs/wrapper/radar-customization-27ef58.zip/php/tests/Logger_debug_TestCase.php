<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'Logger_debug_TestCase::main' );
}

require_once 'PHPUnit/Framework/TestCase.php';
require_once 'PHPUnit/Framework/TestSuite.php';
require_once 'PHPUnit/TextUI/TestRunner.php';

require_once dirname( __FILE__ ) . '/ONAPP/Logger.php';

/**
 * Unit Tests for serializing arrays
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */
class Logger_debug_TestCase extends PHPUnit_Framework_TestCase {

    private $_output = "\[.*\] \[MSG\]   setTimezone: Change default date.timezone.
\[.*\] \[WARN\]  setTimezone: Script timezone differs from ini-set timezone.\n";

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'Logger_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
    }

    protected function tearDown( ) {
    }

    /**
     * Test default debug mode
     */
    public function testDefaultMode( ) {
        $s = new Logger( );

        $r = $s->_debug;

        $this->assertFalse(
            $r
            , "class Logger default debug mode must be set false"
        );
    }

    /**
     * Test disable debug output
     */
    public function testDisableDebugOutput( ) {
        $s = new Logger( );

        $s->setTimezone( );

        $s->setDebug( false );

        $s->debug( "Test" );

        $this->assertRegExp(
            "/" .
            $this->_output .
            "$/"
            , $s->logs( )
            , "Wrong default debug output"
        );
    }

    /**
     * Test enable debug output
     */
    public function testEnableDebugOutput( ) {
        $s = new Logger( );

        $s->setTimezone( );

        $s->setDebug( true );

        $s->debug( "Test" );

        $this->assertRegExp(
            "/" .
            $this->_output .
            "\[.*\] \[DEBUG\] Test$" .
            "/"
            , $s->logs( )
            , "Wrong default debug output"
        );
    }
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'Logger_debug_TestCase::main' ) {
    Logger_debug_TestCase::main( );
}