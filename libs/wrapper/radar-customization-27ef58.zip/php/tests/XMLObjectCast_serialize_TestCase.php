<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'XML_Serializer_Option_AttributesContent_TestCase::main' );
}

require_once 'PHPUnit/Framework/TestCase.php';
require_once 'PHPUnit/Framework/TestSuite.php';
require_once 'PHPUnit/TextUI/TestRunner.php';

require_once dirname( __FILE__ ) . '/ONAPP/XMLObjectCast.php';

/**
 * Unit Tests for serializing arrays
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */
class XMLObjectCast_serialize_TestCase extends PHPUnit_Framework_TestCase {

    private $_serialize_options = null;

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'XML_Serializer_serialize_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
    }

    protected function tearDown( ) {
    }

    /**
     * Test empty XML output
     */
    public function testEmpty( ) {
        $s = new XMLObjectCast( );
        $r = $s->serialize( 'root', null );

        $this->assertXmlStringEqualsXmlString(
            '<?xml version="1.0" encoding="UTF-8"?><root />'
            , $r
        );
    }

    /**
     * Test empty XML tag
     *
     * @depends testEmpty
     */
    public function testEmptyField( ) {
        $s = new XMLObjectCast( $this->_serialize_options );
        $a = array(
            'c' => null,
        );

        $r = $s->serialize( 'root', $a );

        $this->assertXmlStringEqualsXmlString(
            '<?xml version="1.0" encoding="UTF-8"?>' .
            "<root><c/></root>"
            , $r
        );
    }

    /**
     * Test array serialization
     *
     * @depends testEmptyField
     */
    public function testData( ) {
        $s = new XMLObjectCast( $this->_serialize_options );
        $a = array(
            'a' => 'A',
            'b' => 'B'
        );

        $r = $s->serialize( 'root', $a );

        $this->assertXmlStringEqualsXmlString(
            '<?xml version="1.0" encoding="UTF-8"?>' .
            "<root><a>A</a><b>B</b></root>"
            , $r
        );
    }
/*
// TODO
    public function testException() {
        try {
            // ... Code that is expected to raise an exception ...
        }

        catch (InvalidArgumentException $expected) {
            return;
        }

        $this->fail('An expected exception has not been raised.');
    }
*/
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'XML_Serializer_Option_AttributesContent_TestCase::main' ) {
    XML_Serializer_Option_AttributesContent_TestCase::main( );
}