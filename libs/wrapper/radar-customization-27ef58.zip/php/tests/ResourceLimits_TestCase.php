<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'ResourceLimit_TestCase::main' );
}

require_once dirname( __FILE__ ) . '/OnApp_TestCase.php';
require_once dirname( __FILE__ ) . '/ONAPP/ResourceLimit.php';
require_once dirname( __FILE__ ) . '/ONAPP/User.php';

/**
 * Unit Tests for serializing arrays
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */
class ResourceLimits_TestCase extends OnApp_TestCase {

    private $_onapp_config = array( );
    private $_user_ids = array( );

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'ResourceLimits_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
        parent::setUp( );
        $this->getUserIds( );
    }

    private function getUserIds( ) {
        $user = $this->createObj( 'ONAPP_User' );
        $user_list = $user->getList( );
        foreach( $user_list as $item ) {
            $this->_user_ids[ ] = $item->_id;
        }
    }

    protected function tearDown( ) {
    }

    public function testCheckAttributes( ) {
        $obj = $this->createObj( 'ONAPP_ResourceLimit' );
        $obj->_user_id = $this->_user_ids[ 0 ];

        $obj->load( );
        if( !empty( $obj->_obj->error ) ) {
            $this->fail( implode( "\n", $obj->_obj->error ) );
        }

        $obj->setAPIResource( $obj->getResource( ONAPP_GETRESOURCE_LIST ) );

        $response = $obj->sendRequest( ONAPP_REQUEST_METHOD_GET );

        $xmlObjList = simplexml_load_string( $response[ "response_body" ] );

        $vars = array_keys( get_object_vars( $xmlObjList ) );

        sort( $vars );

        $fields = array_keys( $obj->_fields( ) );

        sort( $fields );

        $this->assertEquals(
            $fields,
            $vars
        );

        $this->CheckAttributes( $obj );
    }

    public function testCheckObjectFields( ) {
        $obj = new ONAPP_ResourceLimit( );

        $this->CheckObjectFields( $obj );
    }
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'ResourceLimits_TestCase::main' ) {
    ResourceLimits_TestCase::main( );
}