<?php
/**
 * Unit Tests for serializing
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */

/**
 * PHPUnit main() hack
 *
 * "Call class::main() if this source file is executed directly."
 */
if( !defined( 'PHPUnit_MAIN_METHOD' ) ) {
    define( 'PHPUnit_MAIN_METHOD', 'XML_Unserializer_Option_AttributesContent_TestCase::main' );
}

require_once 'PHPUnit/Framework/TestCase.php';
require_once 'PHPUnit/Framework/TestSuite.php';
require_once 'PHPUnit/TextUI/TestRunner.php';

require_once dirname( __FILE__ ) . '/ONAPP/XMLObjectCast.php';

class ClassA {
    var $_a;
    var $_b;
}

;

/**
 * Unit Tests for serializing arrays
 *
 * @package    ONAPP
 * @subpackage tests
 * @author     Andrew Yatskovets <ayatsk@onapp.com>
 */
class XMLObjectCast_unserialize_TestCase extends PHPUnit_Framework_TestCase {

    public static function main( ) {
        $suite = new PHPUnit_Framework_TestSuite( 'XML_Unserializer_unserialize_TestCase' );
        $result = PHPUnit_TextUI_TestRunner::run( $suite );
    }

    protected function setUp( ) {
    }

    protected function tearDown( ) {
    }

    /**
     * Test empty XML output
     */
    public function testData( ) {

        $obj = new XMLObjectCast( );

        $tagMap = array(
            'a' => array(
                ONAPP_FIELD_MAP => '_a'
            ),
            'b' => array(
                ONAPP_FIELD_MAP => '_b'
            )
        );

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' .
               "<root>" .
               "    <a>A</a>" .
               "    <b>B</b>" .
               "</root>";

        $r = $obj->unserialize( 'ClassA', $xml, $tagMap );

        $this->assertAttributeEquals( "A", "_a", $r );

        $this->assertAttributeEquals( "B", "_b", $r );
    }
}

/**
 * PHPUnit main() hack
 * "Call class::main() if this source file is executed directly."
 */
if( PHPUnit_MAIN_METHOD == 'XML_Unserializer_Option_AttributesContent_TestCase::main' ) {
    XML_Serializer_Option_AttributesContent_TestCase::main( );
}